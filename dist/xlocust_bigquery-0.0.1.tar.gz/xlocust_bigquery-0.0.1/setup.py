from setuptools import setup, find_packages

setup(
    name='xlocust_bigquery',
    version='0.0.1',
    packages=find_packages(),
    license='',
    author='kelvin sanyaolu',
    author_email='kelvin.sanyaolu@gmail.com',
    description='A Google cloud GP Client for locustio to test dataloads and query extraction'
)
